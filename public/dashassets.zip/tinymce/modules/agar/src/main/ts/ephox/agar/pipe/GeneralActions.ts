const debug = function () {
  // tslint:disable-next-line:no-debugger
  debugger;
};

const pass = function () { };

export {
  debug,
  pass
};
