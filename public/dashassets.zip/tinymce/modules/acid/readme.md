# Description
Acid implements the user interface for the TinyMCE 5 colour picker. It also exposes some modules to assist with colour calculations.

# Installation
`acid` is available as an `npm` package.  You can install it via the npm package `@ephox/acid`

## Install from npm
`npm install @ephox/acid`

# Usage

Colour picker is an Alloy component. Usage is evolving during the TinyMCE 5 development process and will be documented at a later date.
