$(document).ready(function () {
    "use strict"; // Start of use strict
    // Replace the <textarea id="editor1"> with a CKEditor
    // instance, using default configuration.
    CKEDITOR.replace('editor1');
});